# Segundo Projeto de N1 2ºBimestre
<strong> Segundo Projeto de N1 </strong><br/>
Integrantes do grupo:<br/>
<strong> Nome: </strong>Vinícius de Andrade Barros <strong>RA:</strong>082150366<br/>
<strong> Nome: </strong>Doriedon Lima da Silva <strong>RA:</strong>082150144
